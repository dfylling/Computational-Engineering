import numpy as np

def norm2D(my, Sgm, x1, x2):
    x1v, x2v = np.meshgrid(x1, x2)
    [n,d]=np.shape(x1v)
    l=2
    p = np.zeros(np.shape(x1v))
    for i in np.arange(0, n):
        for j in np.arange(0, d):
            x = np.array([x1v[i,j], x2v[i,j]])
            #p[i, j] = (2 * np.pi)**(-2/2) * np.sqrt(np.linalg.det(Sgm)) * np.exp(-1 / 2 * (np.array([x1v[i,j], x2v[i,j]]) - my) @ np.invert(Sgm) @ (np.array(x1v[i,j], x2v[i,j]) - my)[:, np.newaxis])
            #p[i, j] = (2 * np.pi)**(-l/2) * np.sqrt(np.linalg.det(Sgm)) * np.exp(-1 / 2 * np.linalg.multi_dot([(x - my)[:, np.newaxis] , np.linalg.inv(Sgm) , x - my]))
            p[i, j] = (2 * np.pi)**(-l/2) * np.power(np.linalg.det(Sgm),-1/2) * np.exp(-1 / 2 * np.linalg.multi_dot([ x - my , np.linalg.inv(Sgm) , (x - my).reshape(-1,1)]))
            
    return p, x1v, x2v